import 'dart:convert';
import 'package:sqflite/sqflite.dart' as sqlite;
import 'package:path/path.dart' as p;
import '../models/product.dart';
import '../models/sale_item.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._();

  sqlite.Database? _db;
  Future<sqlite.Database>? _initFuture;

  Future<sqlite.Database> get database {
    if (_db != null) {
      return Future.value(_db);
    }
    return _initFuture ??= _init().then((db) {
      _db = db;
      return db;
    });
  }

  Future<sqlite.Database> _init() async {
    final path = p.join(await sqlite.getDatabasesPath(), 'pos.db');
    return sqlite.openDatabase(
      path,
      version: 6,
      onConfigure: (db) async {
        await db.rawQuery('PRAGMA journal_mode = WAL');
        await db.execute('PRAGMA synchronous = NORMAL');
        await db.execute('PRAGMA temp_store = MEMORY');
        await db.execute('PRAGMA cache_size = -8000');
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, v) async {
        await db.execute('''
          CREATE TABLE products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            barcode TEXT UNIQUE NOT NULL,
            price REAL NOT NULL,
            purchase_price REAL NOT NULL DEFAULT 0,
            stock INTEGER NOT NULL DEFAULT 0,
            category TEXT DEFAULT ""
          )
        ''');
        await db.execute('''
          CREATE TABLE sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            total REAL NOT NULL,
            total_profit REAL NOT NULL DEFAULT 0,
            items_count INTEGER NOT NULL,
            items TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE IF NOT EXISTS archived_totals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            total_sales REAL NOT NULL,
            total_profit REAL NOT NULL,
            archived_at TEXT NOT NULL
          )
        ''');
        await db.execute('CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode)');
        await db.execute('CREATE INDEX IF NOT EXISTS idx_sales_created_at ON sales(created_at)');
        await db.execute('''
          CREATE TABLE IF NOT EXISTS parked_carts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            items TEXT NOT NULL,
            total REAL NOT NULL,
            items_count INTEGER NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
      },
      onUpgrade: (db, oldV, newV) async {
        if (oldV < 2) {
          await db.execute('ALTER TABLE products ADD COLUMN purchase_price REAL NOT NULL DEFAULT 0');
          await db.execute('ALTER TABLE sales ADD COLUMN total_profit REAL NOT NULL DEFAULT 0');
        }
        if (oldV < 3) {
          await db.execute('''
            CREATE TABLE IF NOT EXISTS archived_totals (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              total_sales REAL NOT NULL,
              total_profit REAL NOT NULL,
              archived_at TEXT NOT NULL
            )
          ''');
        }
        if (oldV < 4) {
          await db.execute('CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode)');
          await db.execute('CREATE INDEX IF NOT EXISTS idx_sales_created_at ON sales(created_at)');
        }
        if (oldV < 5) {
          await db.execute('CREATE INDEX IF NOT EXISTS idx_products_name ON products(name COLLATE NOCASE)');
          await db.execute('CREATE INDEX IF NOT EXISTS idx_products_category ON products(category)');
        }
        if (oldV < 6) {
          await db.execute('''
            CREATE TABLE IF NOT EXISTS parked_carts (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              items TEXT NOT NULL,
              total REAL NOT NULL,
              items_count INTEGER NOT NULL,
              created_at TEXT NOT NULL
            )
          ''');
        }
      },
    );
  }

  Future<List<Product>> getAllProducts() async {
    final db = await database;
    final maps = await db.query('products', orderBy: 'name COLLATE NOCASE ASC');
    return maps.map((m) => Product.fromMap(m)).toList();
  }

  Future<List<Product>> searchProducts(String q) async {
    if (q.isEmpty) return getAllProducts();
    final db = await database;
    final escaped = q.replaceAll('%', r'\%').replaceAll('_', r'\_');
    final maps = await db.query(
      'products',
      where: 'name LIKE ? ESCAPE \'\\\' OR barcode LIKE ? ESCAPE \'\\\'',
      whereArgs: ['%$escaped%', '%$escaped%'],
      orderBy: 'name COLLATE NOCASE ASC',
      limit: 200,
    );
    return maps.map((m) => Product.fromMap(m)).toList();
  }

  Future<Product?> getProductByBarcode(String barcode) async {
    final db = await database;
    final maps = await db.query(
      'products',
      where: 'barcode = ?',
      whereArgs: [barcode],
      limit: 1,
    );
    if (maps.isEmpty) {
      return null;
    }
    return Product.fromMap(maps.first);
  }

  Future<int> insertProduct(Product product) async {
    final db = await database;
    return db.insert('products', product.toMap());
  }

  Future<void> updateProduct(Product product) async {
    final db = await database;
    await db.update('products', product.toMap(), where: 'id = ?', whereArgs: [product.id]);
  }

  Future<void> deleteProduct(int id) async {
    final db = await database;
    await db.delete('products', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deductStock(int productId, int qty) {
    return deductStockOn(database, productId, qty).then((_) => 1);
  }

  Future<int> deductStockOn(Future<sqlite.Database> dbFuture, int productId, int qty) async {
    final db = await dbFuture;
    return deductStockExec(db, productId, qty);
  }

  Future<int> deductStockExec(sqlite.DatabaseExecutor exec, int productId, int qty) async {
    final r = await exec.rawUpdate(
      'UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?',
      [qty, productId, qty],
    );
    if (r == 0) {
      throw const InsufficientStockException();
    }
    return r;
  }

  Future<int> restoreStock(int productId, int qty) async {
    return restoreStockOn(await database, productId, qty);
  }

  Future<int> restoreStockOn(sqlite.DatabaseExecutor exec, int productId, int qty) async {
    return exec.rawUpdate(
      'UPDATE products SET stock = stock + ? WHERE id = ?',
      [qty, productId],
    );
  }

  Future<int> saveSale(double total, double totalProfit, List<SaleItem> items) async {
    return saveSaleOn(await database, total, totalProfit, items);
  }

  Future<int> saveSaleOn(sqlite.DatabaseExecutor exec, double total, double totalProfit, List<SaleItem> items) async {
    return exec.insert('sales', {
      'total': total,
      'total_profit': totalProfit,
      'items_count': items.length,
      'items': jsonEncode(items.map((i) => i.toMap()).toList()),
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<List<Map<String, dynamic>>> getAllSales() async {
    final db = await database;
    return db.query('sales', orderBy: 'created_at DESC');
  }

  Future<double> getTodaySalesTotal() async {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day).toIso8601String();
    final r = await (await database).rawQuery(
      'SELECT COALESCE(SUM(total), 0) as total FROM sales WHERE created_at >= ?',
      [startOfDay],
    );
    return (r.first['total'] as num).toDouble();
  }

  Future<int> getTodaySalesCount() async {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day).toIso8601String();
    final r = await (await database).rawQuery(
      'SELECT COUNT(*) as count FROM sales WHERE created_at >= ?',
      [startOfDay],
    );
    return r.first['count'] as int;
  }

  Future<void> updateSale(int id, double total, double totalProfit, List<SaleItem> items) async {
    await updateSaleOn(await database, id, total, totalProfit, items);
  }

  Future<void> updateSaleOn(sqlite.DatabaseExecutor exec, int id, double total, double totalProfit, List<SaleItem> items) async {
    await exec.update(
      'sales',
      {
        'total': total,
        'total_profit': totalProfit,
        'items_count': items.length,
        'items': jsonEncode(items.map((i) => i.toMap()).toList()),
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteSale(int id) async {
    await deleteSaleOn(await database, id);
  }

  Future<void> deleteSaleOn(sqlite.DatabaseExecutor exec, int id) async {
    await exec.delete('sales', where: 'id = ?', whereArgs: [id]);
  }

  Future<double> getTotalSalesAllTime() async {
    final r = await (await database).rawQuery(
        'SELECT COALESCE(SUM(total), 0) + COALESCE((SELECT SUM(total_sales) FROM archived_totals), 0) as t FROM sales'
    );
    return (r.first['t'] as num).toDouble();
  }

  Future<double> getTotalProfitAllTime() async {
    final r = await (await database).rawQuery(
        'SELECT COALESCE(SUM(total_profit), 0) + COALESCE((SELECT SUM(total_profit) FROM archived_totals), 0) as t FROM sales'
    );
    return (r.first['t'] as num).toDouble();
  }

  Future<int> countSales() async {
    final r = await (await database).rawQuery('SELECT COUNT(*) as c FROM sales');
    return r.first['c'] as int;
  }

  Future<List<Map<String, dynamic>>> getAllProductsRaw() async {
    final db = await database;
    return db.query('products', orderBy: 'name COLLATE NOCASE ASC');
  }

  Future<List<Map<String, dynamic>>> getAllSalesRaw() async {
    final db = await database;
    return db.query('sales', orderBy: 'created_at DESC');
  }

  Future<int> archiveSales() async {
    final db = await database;
    final countResult = await db.rawQuery('SELECT COUNT(*) as c FROM sales');
    final count = countResult.first['c'] as int;
    if (count == 0) return 0;
    final totals = await db.rawQuery(
        'SELECT COALESCE(SUM(total), 0) as ts, COALESCE(SUM(total_profit), 0) as tp FROM sales'
    );
    final totalSales = (totals.first['ts'] as num).toDouble();
    final totalProfit = (totals.first['tp'] as num).toDouble();
    await db.transaction((txn) async {
      await txn.insert('archived_totals', {
        'total_sales': totalSales,
        'total_profit': totalProfit,
        'archived_at': DateTime.now().toIso8601String(),
      });
      await txn.delete('sales');
    });
    return count;
  }



  Future<void> insertSaleFromBackup(Map<String, dynamic> sale) async {
    final db = await database;
    await db.insert('sales', {
      'total': sale['total'],
      'total_profit': sale['total_profit'],
      'items_count': sale['items_count'],
      'items': sale['items'],
      'created_at': sale['created_at'],
    });
  }

  Future<void> insertArchivedTotal(double totalSales, double totalProfit) async {
    final db = await database;
    await db.insert('archived_totals', {
      'total_sales': totalSales,
      'total_profit': totalProfit,
      'archived_at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> parkCart(String name, List<SaleItem> items) async {
    final db = await database;
    final total = items.fold(0.0, (s, i) => s + i.subtotal);
    await db.insert('parked_carts', {
      'name': name,
      'items': jsonEncode(items.map((i) => i.toMap()).toList()),
      'total': total,
      'items_count': items.length,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<int> getParkedCartCount() async {
    final r = await (await database).rawQuery('SELECT COUNT(*) as c FROM parked_carts');
    return r.first['c'] as int;
  }

  Future<List<Map<String, dynamic>>> getParkedCarts() async {
    return (await database).query('parked_carts', orderBy: 'created_at DESC');
  }

  Future<Map<String, dynamic>?> getParkedCart(int id) async {
    final r = await (await database).query('parked_carts', where: 'id = ?', whereArgs: [id], limit: 1);
    return r.isEmpty ? null : r.first;
  }

  Future<void> deleteParkedCart(int id) async {
    await (await database).delete('parked_carts', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteOldestParkedCart() async {
    final r = await (await database).rawQuery(
      'SELECT id FROM parked_carts ORDER BY created_at ASC LIMIT 1'
    );
    if (r.isNotEmpty) {
      await deleteParkedCart(r.first['id'] as int);
    }
  }
}

class InsufficientStockException implements Exception {
  final int productId;
  final int requested;
  const InsufficientStockException({this.productId = 0, this.requested = 0});

  @override
  String toString() => 'InsufficientStockException(product=$productId, requested=$requested)';
}
